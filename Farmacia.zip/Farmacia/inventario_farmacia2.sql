/*
SQLyog Community v13.1.6 (64 bit)
MySQL - 10.4.19-MariaDB : Database - inventario_farmacia
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`inventario_farmacia` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `inventario_farmacia`;

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `cart_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `cart_qty` int(11) NOT NULL,
  `cart_stock_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `cart_uniqid` varchar(35) NOT NULL,
  PRIMARY KEY (`cart_id`),
  KEY `item_id` (`item_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`),
  CONSTRAINT `cart_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

/*Data for the table `cart` */

/*Table structure for table `expired` */

DROP TABLE IF EXISTS `expired`;

CREATE TABLE `expired` (
  `exp_id` int(11) NOT NULL AUTO_INCREMENT,
  `exp_itemName` varchar(50) NOT NULL,
  `exp_itemPrice` float NOT NULL,
  `exp_itemQty` int(11) NOT NULL,
  `exp_expiredDate` date NOT NULL,
  PRIMARY KEY (`exp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `expired` */

/*Table structure for table `item` */

DROP TABLE IF EXISTS `item`;

CREATE TABLE `item` (
  `item_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_name` varchar(50) NOT NULL,
  `item_price` double NOT NULL,
  `item_type_id` int(11) NOT NULL,
  `item_code` varchar(35) NOT NULL,
  `item_brand` varchar(50) NOT NULL,
  `item_grams` varchar(20) NOT NULL,
  PRIMARY KEY (`item_id`),
  KEY `item_type_id` (`item_type_id`),
  CONSTRAINT `item_ibfk_1` FOREIGN KEY (`item_type_id`) REFERENCES `item_type` (`item_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

/*Data for the table `item` */

insert  into `item`(`item_id`,`item_name`,`item_price`,`item_type_id`,`item_code`,`item_brand`,`item_grams`) values 
(7,'Gabapentin',62,1,'557-11','Actavis','400'),
(8,'Paracetamol',1,1,'59477','Senica','300');

/*Table structure for table `item_type` */

DROP TABLE IF EXISTS `item_type`;

CREATE TABLE `item_type` (
  `item_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_type_desc` varchar(50) NOT NULL,
  PRIMARY KEY (`item_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `item_type` */

insert  into `item_type`(`item_type_id`,`item_type_desc`) values 
(1,'Tabletas'),
(2,'Jarabe');

/*Table structure for table `sales` */

DROP TABLE IF EXISTS `sales`;

CREATE TABLE `sales` (
  `sales_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_code` varchar(35) NOT NULL,
  `generic_name` varchar(35) NOT NULL,
  `brand` varchar(35) NOT NULL,
  `gram` varchar(35) NOT NULL,
  `type` varchar(35) NOT NULL,
  `qty` int(11) NOT NULL,
  `price` float NOT NULL,
  `date_sold` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`sales_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

/*Data for the table `sales` */

insert  into `sales`(`sales_id`,`item_code`,`generic_name`,`brand`,`gram`,`type`,`qty`,`price`,`date_sold`) values 
(1,'59477','Paracetamol','Senica','300','Tabletas',5,1,'2022-04-19 16:26:24'),
(2,'59477','Paracetamol','Senica','300','Tabletas',2,1,'2022-04-19 16:26:24'),
(3,'59477','Paracetamol','Senica','300','Tabletas',2,1,'2022-04-19 17:21:32'),
(4,'59477','Paracetamol','Senica','300','Tabletas',2,1,'2022-04-19 17:21:32'),
(5,'557-11','Gabapentin','Actavis','400','Tabletas',3,61,'2022-04-24 20:46:50'),
(6,'557-11','Gabapentin','Actavis','400','Tabletas',3,61,'2022-04-24 20:46:50'),
(7,'557-11','Gabapentin','Actavis','400','Tabletas',3,61,'2022-04-24 20:47:53'),
(8,'59477','Paracetamol','Senica','300','Tabletas',2,1,'2022-04-24 20:47:53'),
(9,'59477','Paracetamol','Senica','300','Tabletas',2,1,'2022-04-24 20:47:54'),
(10,'557-11','Gabapentin','Actavis','400','Tabletas',3,61,'2022-04-24 20:47:54'),
(11,'59477','Paracetamol','Senica','300','Tabletas',2,1,'2022-04-24 20:47:54'),
(12,'557-11','Gabapentin','Actavis','400','Tabletas',1,61,'2022-04-24 22:19:46'),
(13,'557-11','Gabapentin','Actavis','400','Tabletas',1,61,'2022-04-24 22:19:46'),
(14,'59477','Paracetamol','Senica','300','Tabletas',1,1,'2022-05-15 18:46:54'),
(15,'59477','Paracetamol','Senica','300','Tabletas',1,1,'2022-05-15 18:46:54'),
(16,'59477','Paracetamol','Senica','300','Tabletas',1,1,'2022-05-15 18:46:54'),
(17,'557-11','Gabapentin','Actavis','400','Tabletas',1,61,'2022-05-15 19:02:08'),
(18,'557-11','Gabapentin','Actavis','400','Tabletas',1,61,'2022-05-15 19:02:08'),
(19,'557-11','Gabapentin','Actavis','400','Tabletas',1,61,'2022-05-15 19:07:43'),
(20,'557-11','Gabapentin','Actavis','400','Tabletas',1,61,'2022-05-15 19:07:43');

/*Table structure for table `stock` */

DROP TABLE IF EXISTS `stock`;

CREATE TABLE `stock` (
  `stock_id` int(11) NOT NULL AUTO_INCREMENT,
  `item_id` int(11) NOT NULL,
  `stock_qty` int(11) NOT NULL,
  `stock_expiry` date NOT NULL,
  `stock_added` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `stock_manufactured` date NOT NULL,
  `stock_purchased` date NOT NULL,
  PRIMARY KEY (`stock_id`),
  KEY `item_id` (`item_id`),
  CONSTRAINT `stock_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

/*Data for the table `stock` */

insert  into `stock`(`stock_id`,`item_id`,`stock_qty`,`stock_expiry`,`stock_added`,`stock_manufactured`,`stock_purchased`) values 
(1,7,3,'2017-09-15','2022-05-15 18:46:50','2017-05-19','2017-05-20'),
(2,8,2,'2022-12-20','2022-05-16 23:18:41','2022-04-01','2022-04-19'),
(3,8,1,'2022-09-27','2022-04-24 20:47:41','2022-04-01','2022-04-19'),
(4,7,6,'2021-11-03','2022-05-15 20:55:44','2020-12-01','2022-04-19'),
(5,8,1,'2022-09-21','2022-04-21 01:11:38','2022-01-26','2022-04-21');

/*Table structure for table `suppliers` */

DROP TABLE IF EXISTS `suppliers`;

CREATE TABLE `suppliers` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `address` varchar(500) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `fax` varchar(200) NOT NULL,
  `info` text NOT NULL,
  `added_date` date NOT NULL,
  `delete_status` tinyint(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

/*Data for the table `suppliers` */

insert  into `suppliers`(`id`,`name`,`address`,`telephone`,`fax`,`info`,`added_date`,`delete_status`) values 
(1,'juan perez','dualshot@hotmail.com','+51 985478987','422208111','medicamentos por lotes','2019-04-02',0),
(2,'debbi ssanti','debis@hotmail.com','+51 986762212','12341556','tabletas','2022-04-20',0);

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_account` varchar(50) NOT NULL,
  `user_pass` varchar(35) NOT NULL,
  `user_type` int(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `user` */

insert  into `user`(`user_id`,`user_account`,`user_pass`,`user_type`) values 
(1,'admin','21232f297a57a5a743894a0e4a801fc3',1),
(2,'admin2','21232f297a57a5a743894a0e4a801fc3',1),
(3,'deybis','91ea863f214c137fadad7dc6a9471b62',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
