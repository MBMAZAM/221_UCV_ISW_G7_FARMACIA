<?php
require_once('../database/Database.php');
require_once('../interface/iproveedores.php');
class proveedor extends Database implements iproveedores {
	public function all_proveedores()
	{
		$sql = "SELECT *
				FROM suppliers";
		return $this->getRows($sql);
	}
	
	
}



