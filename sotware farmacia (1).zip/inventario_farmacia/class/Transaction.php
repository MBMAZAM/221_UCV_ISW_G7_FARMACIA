<?php
require_once('../database/Database.php');
require_once('../interface/iTransaction.php');
class Transaction extends Database implements iTransaction {
	

}//
$transaction = new Transaction();//

