<?php 
interface iproveedores{
	public function all_proveedores();
	
}