<?php 
interface iTransaction{
}