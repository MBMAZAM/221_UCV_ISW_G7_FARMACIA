<?php 
    require_once('../class/proveedor.php');
   $pro = $pro->all_proveedores();
   
 ?>
<br />
<div class="table-responsive">
        <table id="myTable-proveedor" class="table table-bordered table-hover table-striped">
            <thead>
                <tr>
              
            <td>nombre</td>
            <td>address </td>
            <td>telephone</td>
            <td>fax</td>
            <td>info</td>
            <td>Fecha</td>      
                </tr>
            </thead>
            <tbody>
            <tbody>

            <?php foreach($pro as $p): ?>
                <tr align="center">
                    <td><?= ucwords($p['name']); ?></td>    
                    <td><?= $p['address']; ?></td>
                    <td><?= $p['telephone']; ?></td>
                    <td><?= $p['fax']; ?></td>
                    <td><?= $p['info']; ?></td>
                    <td><?= $p['added_date']; ?></td>
                    
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
</div>


<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />
<br /><br /><br /><br /><br /><br /><br /><br /><br /><br /><br />

<script type="text/javascript">
    $(document).ready(function() {
        $('#myTable-proveedor').DataTable();
    });
</script>

<?php 
$pro->Disconnect();
 ?>